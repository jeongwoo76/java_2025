package com.yoonlee3.diary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
class Diary1ApplicationTests {

	public static void main(String[] args) {
		SpringApplication.run(Diary1Application.class, args);
	}
}
